//
//  ViewController.swift
//  ios-CW-5-p1
//
//  Created by Bdour Almesri on 27/06/2020.
//  Copyright © 2020 mohammed almesri. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var nameLable: UILabel!
    @IBOutlet weak var nameLable2: UILabel!
    @IBOutlet weak var classLable: UILabel!
    @IBOutlet weak var nameField: UITextField!
    @IBOutlet weak var gradeField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func press(_ sender: Any) {
        nameLable.text = nameField.text
        nameLable2.text = gradeField.text
        
    }
    
}

